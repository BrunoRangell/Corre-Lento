(function () {
  "use strict";
  var C = window.CONFIG;

  // ---------- armazenamento local ----------
  var LS = {
    get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
    del: function (k) { try { localStorage.removeItem(k); } catch (e) {} }
  };

  var state = {
    token: LS.get("cc_token"),
    eu: null,
    tab: "feed",
    feed: null,
    rank: null,
    rankMode: "semana",
    authMode: "entrar",
    auth: { nome: LS.get("cc_nome") || "", senha: "", senha2: "" },
    pw: { atual: "", nova: "" },
    novo: { nome: "", senha: "" },
    form: { dia: 0, minutos: "", km: "", nota: "", foto: null },
    drafts: {},
    perfil: null,
    temps: null,
    photos: {},
    photoFail: {},
    photoBusy: false,
    avatares: {},
    avBusy: false,
    cfg: { minimo: "", meta: "", max: "", tempNome: "", tempSemanas: "8" },
    update: null,
    updateDismissed: null,
    appInfo: null,
    ota: null,
    otaDismissed: null,
    busy: false
  };

  // ---------- utilidades ----------
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function parseD(s) { var p = String(s).split("-").map(Number); return new Date(p[0], p[1] - 1, p[2]); }
  function toISO(d) { return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
  function addDays(iso, n) { var d = parseD(iso); d.setDate(d.getDate() + n); return toISO(d); }
  var DIAS = ["dom", "seg", "ter", "qua", "qui", "sex", "sáb"];
  function labelData(iso) {
    var hoje = state.eu ? state.eu.hoje : toISO(new Date());
    if (iso === hoje) return "Hoje";
    if (iso === addDays(hoje, -1)) return "Ontem";
    var d = parseD(iso);
    return DIAS[d.getDay()] + " " + pad(d.getDate()) + "/" + pad(d.getMonth() + 1);
  }
  function fmtKm(km) {
    return Number(km).toLocaleString("pt-BR", { minimumFractionDigits: 1, maximumFractionDigits: 2 });
  }
  function fmtPace(min, km) {
    if (!km || Number(km) <= 0) return null;
    var secs = Math.round((min / Number(km)) * 60);
    return Math.floor(secs / 60) + ":" + pad(secs % 60) + " /km";
  }
  function fmtMin(m) {
    if (m < 60) return m + " min";
    return Math.floor(m / 60) + "h" + pad(m % 60);
  }
  var CORES = ["#ff6b2c", "#3ea6ff", "#a06bff", "#3ecf8e", "#f5b942", "#ff5d8f", "#2ec4b6", "#8d99ae"];
  function corDe(nome) {
    var h = 0;
    for (var i = 0; i < nome.length; i++) h = (h * 31 + nome.charCodeAt(i)) >>> 0;
    return CORES[h % CORES.length];
  }

  // ---------- ícones (traço contínuo, mesmo peso em todos) ----------
  var ICONES = {
    home: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9.5h13V10"/><path d="M10 19.5v-5h4v5"/>',
    trophy: '<path d="M8 4h8v5a4 4 0 0 1-8 0V4z"/><path d="M8 6H5.2a.8.8 0 0 0-.8.9C4.7 9 6 10.4 8.2 10.6"/><path d="M16 6h2.8a.8.8 0 0 1 .8.9C19.3 9 18 10.4 15.8 10.6"/><path d="M12 13.2V17"/><path d="M9.5 20h5"/><path d="M10.2 17h3.6"/>',
    plus: '<path d="M12 5.5v13M5.5 12h13"/>',
    users: '<circle cx="9" cy="8.5" r="3.1"/><path d="M3.4 19.2c.5-3.2 2.7-5 5.6-5s5.1 1.8 5.6 5"/><circle cx="17.2" cy="9.4" r="2.5"/><path d="M16.6 14.3c2.3.1 3.9 1.6 4.4 4.2"/>',
    user: '<circle cx="12" cy="8.4" r="3.6"/><path d="M5 20.2c.7-4 3.5-6.2 7-6.2s6.3 2.2 7 6.2"/>',
    refresh: '<path d="M19.5 11A7.5 7.5 0 1 0 17.3 16.4"/><path d="M19.8 4.8V11h-6.2"/>',
    more: '<circle cx="5.5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="18.5" cy="12" r="1.4"/>',
    camera: '<path d="M4 8.5A1.5 1.5 0 0 1 5.5 7H8l1.2-2h5.6L16 7h2.5A1.5 1.5 0 0 1 20 8.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 17.5z"/><circle cx="12" cy="13" r="3.6"/>',
    image: '<rect x="4" y="5" width="16" height="14" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="m5 17 4.5-4.5 3 3L15 13l4 4"/>',
    trash: '<path d="M5 7h14"/><path d="M9.5 7V5h5v2"/><path d="M7 7l.8 12h8.4L17 7"/><path d="M10 11v5M14 11v5"/>',
    lock: '<rect x="5" y="10.5" width="14" height="9.5" rx="2"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>',
    logout: '<path d="M10 5H6.5A1.5 1.5 0 0 0 5 6.5v11A1.5 1.5 0 0 0 6.5 19H10"/><path d="M14.5 8.5 18 12l-3.5 3.5"/><path d="M18 12H9.5"/>',
    chevron: '<path d="m9.5 6 6 6-6 6"/>',
    bell: '<path d="M6.5 16.5V11a5.5 5.5 0 0 1 11 0v5.5L19 18H5z"/><path d="M10 20.5a2.2 2.2 0 0 0 4 0"/>',
    flame: '<path d="M12 3c.6 3.2 3.9 4.9 3.9 9a3.9 3.9 0 0 1-7.8 0c0-1.5.6-2.5 1.4-3.4.2 1 .8 1.6 1.5 1.8C10.3 8.3 11 5.6 12 3z"/>'
  };
  function icon(nome, tam) {
    return '<svg class="svgi" width="' + (tam || 24) + '" height="' + (tam || 24) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICONES[nome] + "</svg>";
  }

  // ---------- medalhas ----------
  var MEDALHAS = {
    primeiro: { t: "bronze", l: "1" }, t10: { t: "bronze", l: "10" }, t25: { t: "prata", l: "25" }, t50: { t: "ouro", l: "50" },
    km5: { t: "bronze", l: "5K" }, km10: { t: "prata", l: "10K" }, km21: { t: "ouro", l: "21K" },
    semcheia: { t: "prata", l: "4x" }, seq4: { t: "prata", l: "4", f: 1 }, seq8: { t: "ouro", l: "8", f: 1 }
  };
  var TIERS = {
    bronze: ["#e9a56b", "#b0672f", "#5e300d"], prata: ["#f1f4f8", "#aab4c2", "#6d7887"], ouro: ["#ffe28a", "#e8b22e", "#9a6a05"]
  };
  function medalha(id, ok) {
    var m = MEDALHAS[id] || { t: "bronze", l: "?" }, c = TIERS[m.t], u = "m" + id;
    var cor = ok ? c : ["#3a404c", "#2b303a", "#20242c"], txt = ok ? c[2] : "#5b6372", fita = ok ? (m.t === "ouro" ? "#d6453d" : m.t === "prata" ? "#3d7bd6" : "#3aa66b") : "#2a2e37";
    return '<svg class="medal" viewBox="0 0 64 78" aria-hidden="true">' +
      '<defs><linearGradient id="' + u + '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + cor[0] + '"/><stop offset=".55" stop-color="' + cor[1] + '"/><stop offset="1" stop-color="' + cor[2] + '"/></linearGradient></defs>' +
      '<path d="M18 0h11l7 25-9 3z" fill="' + fita + '"/><path d="M46 0H35l-7 25 9 3z" fill="' + fita + '" opacity=".85"/>' +
      '<circle cx="32" cy="48" r="27" fill="url(#' + u + ')"/>' +
      '<circle cx="32" cy="48" r="21.5" fill="none" stroke="' + (ok ? "rgba(255,255,255,.65)" : "rgba(255,255,255,.1)") + '" stroke-width="1.6"/>' +
      (ok ? '<path d="M15 40a19 19 0 0 1 14-13" fill="none" stroke="rgba(255,255,255,.55)" stroke-width="2.4" stroke-linecap="round"/>' : "") +
      (m.f ? '<g transform="translate(24.5 55) scale(.64)" fill="' + txt + '" opacity=".9"><path d="M12 3c.6 3.2 3.9 4.9 3.9 9a3.9 3.9 0 0 1-7.8 0c0-1.5.6-2.5 1.4-3.4.2 1 .8 1.6 1.5 1.8C10.3 8.3 11 5.6 12 3z"/></g>' : "") +
      '<text x="32" y="' + (m.f ? 51 : 55) + '" text-anchor="middle" font-size="' + (m.l.length > 2 ? 17 : 21) + '" font-weight="800" font-family="system-ui,sans-serif" fill="' + txt + '"' + (ok ? ' stroke="rgba(255,255,255,.45)" stroke-width=".8" paint-order="stroke"' : "") + '>' + m.l + "</text></svg>";
  }

  // ---------- painel inferior (confirmações, menus e formulários) ----------
  function sheet(o) {
    var ov = document.createElement("div");
    ov.className = "sheetwrap";
    var h = '<div class="sheet" role="dialog"><div class="grip"></div>';
    if (o.titulo) h += "<h3>" + esc(o.titulo) + "</h3>";
    if (o.texto) h += '<p class="sheettxt">' + esc(o.texto) + "</p>";
    (o.campos || []).forEach(function (c) {
      h += "<label>" + esc(c.rotulo) + '</label><input data-f="' + c.id + '" type="' + (c.tipo || "text") + '" value="' + esc(c.valor || "") + '" placeholder="' + esc(c.ph || "") + '" maxlength="64" autocomplete="off">';
    });
    h += '<div class="sheetacts">' + o.acoes.map(function (a, i) {
      return '<button class="sbtn ' + (a.tipo || "ghost") + '" data-i="' + i + '">' + (a.icone ? icon(a.icone, 20) : "") + "<span>" + esc(a.rotulo) + "</span></button>";
    }).join("") + "</div></div>";
    ov.innerHTML = h;
    document.body.appendChild(ov);
    requestAnimationFrame(function () { ov.classList.add("open"); });
    function fechar() { ov.classList.remove("open"); setTimeout(function () { ov.remove(); }, 220); }
    ov.addEventListener("click", function (e) {
      if (e.target === ov) { fechar(); return; }
      var b = e.target.closest("[data-i]");
      if (!b) return;
      var a = o.acoes[Number(b.dataset.i)], vals = {};
      [].forEach.call(ov.querySelectorAll("[data-f]"), function (i) { vals[i.dataset.f] = i.value; });
      if (a.fn && a.fn(vals) === false) return;
      fechar();
    });
    return fechar;
  }
  function confirmar(titulo, texto, rotulo, fn) {
    sheet({ titulo: titulo, texto: texto, acoes: [{ rotulo: rotulo, tipo: "danger", fn: fn }, { rotulo: "Cancelar" }] });
  }

  function avatar(nome, id) {
    var a = id && state.avatares[id];
    if (a && a.img) return '<img class="avatar" alt="" src="' + esc(a.img) + '">';
    return '<div class="avatar" style="background:' + corDe(nome) + '">' + esc(nome.trim().charAt(0).toUpperCase()) + "</div>";
  }

  var toastTimer = null;
  function toast(msg, isErr) {
    var el = document.getElementById("toast");
    el.textContent = msg;
    el.className = "toast show" + (isErr ? " err" : "");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.className = "toast"; }, isErr ? 4200 : 2400);
  }

  // ---------- API ----------
  function rpc(name, args) {
    return fetch(C.SUPABASE_URL + "/rest/v1/rpc/" + name, {
      method: "POST",
      headers: { apikey: C.SUPABASE_KEY, "Content-Type": "application/json" },
      body: JSON.stringify(args || {})
    }).then(function (res) {
      return res.text().then(function (txt) {
        var data = null;
        try { data = txt ? JSON.parse(txt) : null; } catch (e) { data = txt; }
        if (!res.ok) {
          var msg = (data && data.message) || "Erro inesperado";
          if (msg === "sessao_invalida") {
            sair(true);
            throw new Error("Sua sessão expirou. Entre de novo.");
          }
          throw new Error(msg);
        }
        return data;
      });
    }, function () {
      throw new Error("Sem conexão. Confira a internet e tente de novo.");
    });
  }
  function tk(extra) { var o = { p_token: state.token }; for (var k in extra) o[k] = extra[k]; return o; }

  function loadMe() { return rpc("corrida_eu", tk({})).then(function (d) { state.eu = d; }); }
  function loadFeed() { return rpc("corrida_feed", tk({ p_limite: 40 })).then(function (d) { state.feed = d; }); }
  function loadRank() { return rpc("corrida_ranking", tk({})).then(function (d) { state.rank = d; }); }
  function loadAvatars() {
    var eu = state.eu;
    if (!eu || state.avBusy) return;
    var ids = (eu.membros || []).filter(function (m) {
      var a = state.avatares[m.id];
      if (!m.av) { if (a && a.img) { state.avatares[m.id] = { v: 0, img: null }; } return false; }
      return !a || a.v !== m.av;
    });
    if (!ids.length) return;
    state.avBusy = true;
    rpc("corrida_avatares", tk({ p_ids: ids.map(function (m) { return m.id; }) })).then(function (map) {
      ids.forEach(function (m) { state.avatares[m.id] = { v: m.av, img: map[m.id] || null }; });
      state.avBusy = false; render();
    }, function () { state.avBusy = false; });
  }
  function loadPhotos() {
    if (state.photoBusy || !state.feed) return;
    var falta = state.feed.filter(function (t) { return t.tem_foto; }).slice(0, 12)
      .filter(function (t) { return !state.photos[t.id] && !state.photoFail[t.id]; })
      .slice(0, 4).map(function (t) { return t.id; });
    if (!falta.length) return;
    state.photoBusy = true;
    rpc("corrida_fotos", tk({ p_ids: falta })).then(function (map) {
      falta.forEach(function (id) { if (map[id]) state.photos[id] = map[id]; else state.photoFail[id] = true; });
      state.photoBusy = false; render(); loadPhotos();
    }, function () { falta.forEach(function (id) { state.photoFail[id] = true; }); state.photoBusy = false; render(); });
  }
  // ---------- avisos no celular (push) e lembrete diário ----------
  function noop() {}
  function plug(n) { return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins[n]; }
  var pushListeners = false;
  function registrarPush() {
    var Pn = plug("PushNotifications");
    if (!Pn || !state.token) return;
    if (!pushListeners) {
      pushListeners = true;
      Pn.createChannel({ id: "corre-lento", name: "Corre Lento", description: "Avisos do grupo", importance: 4, visibility: 1 }).catch(noop);
      Pn.addListener("registration", function (t) {
        LS.set("cc_fcm", t.value);
        if (state.token) rpc("corrida_push_registrar", tk({ p_fcm: t.value })).catch(noop);
      });
      Pn.addListener("registrationError", noop);
      Pn.addListener("pushNotificationReceived", function (n) {
        toast((n.title || "") + (n.body ? ": " + n.body : ""));
        if (state.token) refreshAll(true);
      });
      Pn.addListener("pushNotificationActionPerformed", function () {
        state.tab = "feed"; render();
        if (state.token) refreshAll(true);
      });
    }
    Pn.checkPermissions().then(function (r) {
      if (r.receive === "granted" || r.receive === "denied") return r;
      return Pn.requestPermissions();
    }).then(function (r) {
      state.pushPerm = r.receive;
      if (r.receive === "granted") Pn.register();
      render();
    }).catch(noop);
  }
  function lembCfg() {
    try { var c = JSON.parse(LS.get("cc_lembrete") || "null"); if (c && c.hora) return c; } catch (e) {}
    return { on: false, hora: "19:00" };
  }
  var lembChave = "";
  function agendarLembrete(forcar) {
    var L = plug("LocalNotifications");
    if (!L || !state.eu || !state.feed) return;
    var cfg = lembCfg();
    var treinouHoje = state.feed.some(function (t) { return t.membro_id === state.eu.membro.id && t.data === state.eu.hoje; });
    var chave = [cfg.on, cfg.hora, treinouHoje, state.eu.hoje].join("|");
    if (!forcar && chave === lembChave) return;
    lembChave = chave;
    L.cancel({ notifications: [{ id: 1 }] }).catch(noop).then(function () {
      if (!cfg.on) return;
      var hm = cfg.hora.split(":");
      var at = new Date(); at.setHours(Number(hm[0]), Number(hm[1]), 0, 0);
      if (at <= new Date() || treinouHoje) at.setDate(at.getDate() + 1);
      return L.schedule({ notifications: [{
        id: 1, title: "Corre Lento", body: "Já correu hoje? Registra o treino aí.",
        schedule: { at: at, every: "day", allowWhileIdle: true }, channelId: "corre-lento"
      }] });
    }).catch(noop);
  }
  function carregarPerfil(id) {
    state.perfil = { id: id, dados: null };
    render();
    rpc("corrida_perfil", tk({ p_membro: id || null })).then(function (d) {
      if (state.perfil && state.perfil.id === id) { state.perfil.dados = d; render(); }
    }, function (e) { toast(e.message, true); });
  }
  function carregarTemporadas() {
    rpc("corrida_temporadas", tk({})).then(function (d) { state.temps = d; render(); }, noop);
  }
  function refreshAll(silent) {
    return Promise.all([loadMe(), loadFeed(), loadRank()]).then(function () { render(); loadAvatars(); loadPhotos(); agendarLembrete(); }, function (e) {
      if (!silent) toast(e.message, true);
      render();
    });
  }

  // ---------- sessão ----------
  function sair(expirou) {
    if (!expirou && state.token) {
      var fcm = LS.get("cc_fcm");
      if (fcm) rpc("corrida_push_remover", tk({ p_fcm: fcm })).catch(noop);
      rpc("corrida_logout", { p_token: state.token }).catch(function () {});
    }
    LS.del("cc_token");
    state.token = null; state.eu = null; state.feed = null; state.rank = null; state.avatares = {}; state.photos = {}; state.photoFail = {};
    state.auth.senha = ""; state.auth.senha2 = ""; state.authMode = "entrar";
    render();
  }
  function entrou(token) {
    state.token = token;
    LS.set("cc_token", token);
    LS.set("cc_nome", state.auth.nome.trim());
    state.auth.senha = ""; state.auth.senha2 = "";
    state.tab = "feed";
    state.feed = null; state.rank = null;
    render();
    registrarPush();
    return refreshAll(false);
  }

  // ---------- telas ----------
  // ---------- aviso de nova versão ----------
  function viewUpdate() { return viewApk() || viewOta(); }
  function viewOta() {
    var o = state.ota;
    if (!o || o.status === "erro" || state.otaDismissed === o.version) return "";
    if (o.status === "baixando") {
      return '<div class="update"><div class="grow"><b>Baixando atualização...</b></div></div>';
    }
    var notas = o.notas ? '<div class="xs" style="margin-top:2px;opacity:.9">' + esc(o.notas) + "</div>" : "";
    return '<div class="update"><div class="grow"><b>Atualização pronta</b>' + notas + "</div>" +
      '<button class="btn small" data-act="aplicarota">Atualizar agora</button>' +
      '<button class="btn small ghost" data-act="depoisota">Depois</button></div>';
  }
  function viewApk() {
    var u = state.update;
    if (!u || (!u.obrigatoria && state.updateDismissed === u.version_code)) return "";
    var notas = u.notas ? '<div class="xs" style="margin-top:2px;opacity:.9">' + esc(u.notas) + "</div>" : "";
    if (u.obrigatoria) {
      return '<div class="blocker"><div class="blocker-box"><div style="font-size:42px">🐌</div>' +
        "<h2>Precisa atualizar</h2><p class=\"muted\" style=\"line-height:1.45\">A versão " + esc(u.version_name) +
        " do Corre Lento já saiu e esta versão não funciona mais.</p>" + notas +
        '<button class="btn" data-act="atualizarapp">Atualizar agora</button></div></div>';
    }
    return '<div class="update"><div class="grow"><b>Nova versão ' + esc(u.version_name) + " disponível</b>" + notas + "</div>" +
      '<button class="btn small" data-act="atualizarapp">Atualizar agora</button>' +
      '<button class="btn small ghost" data-act="depois">Depois</button></div>';
  }
  function appBuild() {
    var A = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
    var fallback = Number(C.APP_VERSION_CODE) || 1;
    if (A && A.getInfo) {
      return A.getInfo().then(function (i) { return parseInt(i.build, 10) || fallback; }, function () { return fallback; });
    }
    return Promise.resolve(fallback);
  }
  function loadAppInfo() {
    var A = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
    if (!A || !A.getInfo) return Promise.resolve();
    return A.getInfo().then(function (i) { state.appInfo = { version: i.version, build: i.build }; }, function () {});
  }
  function updater() { return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater; }
  function notifyReady() {
    var U = updater();
    if (U && U.notifyAppReady) U.notifyAppReady().catch(function () {});
  }
  // atualização instantânea: baixa só os arquivos do app (poucos KB), confere o checksum e troca na hora
  function startOta(v, mine) {
    var U = updater();
    if (!U || !v || !v.web_url || !v.web_checksum || !/^https:\/\//.test(v.web_url)) return;
    var ver = Number(v.web_version);
    if (!(ver > Number(C.WEB_VERSION))) { state.ota = null; return; }
    if (Number(v.web_min_apk) > mine) return; // este pacote exige um APK mais novo
    if (state.ota && state.ota.version === ver && state.ota.status !== "erro") return;
    state.ota = { version: ver, status: "baixando", id: null, notas: v.notas || "" };
    U.download({ url: v.web_url, version: String(ver), checksum: v.web_checksum }).then(function (b) {
      state.ota = { version: ver, status: "pronta", id: b.id, notas: v.notas || "" };
      render();
    }, function () { state.ota = { version: ver, status: "erro" }; render(); });
  }
  function checkUpdate() {
    return Promise.all([rpc("corrida_versao", {}), appBuild()]).then(function (r) {
      var v = r[0], mine = r[1];
      var novo = v && v.apk_url && /^https:\/\//.test(v.apk_url) && Number(v.version_code) > mine;
      state.update = novo ? v : null;
      startOta(v, mine);
      render();
    }, function () { /* sem internet: tenta na próxima vez */ });
  }

  function viewAuth() {
    var a = state.auth, criar = state.authMode === "criar";
    return viewUpdate() + '<div class="auth">' +
      '<h1>🐌 Corre<br>Lento</h1>' +
      '<p class="lead">' + (criar ? "Crie sua conta com nome e senha. Quem criar primeiro vira o organizador do grupo." : "Entre com seu nome e sua senha.") + "</p>" +
      '<div class="seg"><button class="' + (!criar ? "on" : "") + '" data-act="authmode" data-v="entrar">Entrar</button>' +
      '<button class="' + (criar ? "on" : "") + '" data-act="authmode" data-v="criar">Criar conta</button></div>' +
      '<label>Seu nome</label><input data-model="auth.nome" value="' + esc(a.nome) + '" maxlength="24" placeholder="Como o pessoal te chama" autocomplete="off">' +
      '<label>Senha' + (criar ? " (mínimo 6 caracteres)" : "") + '</label><input data-model="auth.senha" value="' + esc(a.senha) + '" type="password" maxlength="64" placeholder="Sua senha" autocomplete="off">' +
      (criar ? '<label>Repita a senha</label><input data-model="auth.senha2" value="' + esc(a.senha2) + '" type="password" maxlength="64" placeholder="Mesma senha" autocomplete="off">' : "") +
      '<button class="btn" data-act="auth"' + (state.busy ? " disabled" : "") + ">" + (state.busy ? "Aguarde..." : criar ? "Criar conta" : "Entrar") + "</button>" +
      '<p class="small muted center" style="margin-top:18px">Corre lento, mas corre. Aqui vale a constância, não o pace.</p>' +
    "</div>";
  }

  function cardTreino(t) {
    var eu = state.eu;
    var need = Math.floor(t.ativos / 2) + 1;
    var pace = fmtPace(t.minutos, t.km);
    var h = '<div class="card' + (t.contestado ? " contested" : "") + '">';
    h += '<div class="row linkrow" data-act="verperfil" data-id="' + esc(t.membro_id) + '">' + avatar(t.nome, t.membro_id) + '<div class="grow"><b>' + esc(t.nome) + '</b><div class="xs muted">' + esc(labelData(t.data)) + "</div></div>";
    if (t.contestado) h += '<span class="badge bad">🚩 Contestado · sem ponto</span>';
    else if (t.votos > 0) h += '<span class="badge warn">Em análise</span>';
    if (t.pode_apagar) h += '<button class="iconmini" data-act="menutreino" data-id="' + esc(t.id) + '" aria-label="Mais opções">' + icon("more", 20) + "</button>";
    h += "</div>";
    h += '<div class="stat"><div><b>' + esc(fmtMin(t.minutos)) + "</b><span>tempo</span></div>";
    if (t.km != null && Number(t.km) > 0) h += "<div><b>" + esc(fmtKm(t.km)) + "</b><span>km</span></div>";
    if (pace) h += "<div><b>" + esc(pace) + "</b><span>ritmo</span></div>";
    h += "</div>";
    if (t.nota) h += '<p class="note">' + esc(t.nota) + "</p>";
    if (t.tem_foto) {
      if (state.photos[t.id]) h += '<img class="photo" alt="Foto do treino" src="' + esc(state.photos[t.id]) + '">';
      else if (state.photoFail[t.id] || !state.feed || state.feed.filter(function (x) { return x.tem_foto; }).indexOf(t) >= 12)
        h += '<button class="photobtn" data-act="foto" data-id="' + esc(t.id) + '">📷 Ver foto do treino</button>';
      else h += '<div class="photoload">Carregando foto...</div>';
    }
    h += '<div class="reacts">';
    ["🔥", "💪", "👏", "😂"].forEach(function (em) {
      var r = (t.reacoes || []).filter(function (x) { return x.emoji === em; })[0];
      h += '<button class="react' + (r && r.eu ? " on" : "") + '" data-act="reagir" data-id="' + esc(t.id) + '" data-e="' + em + '">' + em + (r ? " " + r.qtd : "") + "</button>";
    });
    h += "</div>";
    if (t.pode_contestar || t.votos > 0) {
      h += '<div class="doubt"><span>' +
        (t.votos > 0 ? t.votos + (t.votos === 1 ? " pessoa duvida" : " pessoas duvidam") + " (com " + need + " o treino perde o ponto)" : "Não parece que esse treino aconteceu? Se mais da metade do grupo duvidar em até 48h, ele não conta ponto.") + "</span>";
      if (t.pode_contestar) h += '<button class="' + (t.eu_votei ? "on" : "") + '" data-act="duvidar" data-id="' + esc(t.id) + '">' + (t.eu_votei ? "Retirar minha dúvida" : "Duvidar deste treino") + "</button>";
      h += "</div>";
    }
    h += '<div class="comments">';
    (t.comentarios || []).forEach(function (c) {
      h += '<div class="comment"><span class="linkrow" data-act="verperfil" data-id="' + esc(c.membro_id) + '">' + avatar(c.nome, c.membro_id) + '</span><div><b class="linkrow" data-act="verperfil" data-id="' + esc(c.membro_id) + '">' + esc(c.nome) + "</b> " + esc(c.texto) + "</div></div>";
    });
    h += '<div class="commentform"><input data-draft="' + esc(t.id) + '" value="' + esc(state.drafts[t.id] || "") + '" maxlength="280" placeholder="Comentar..." autocomplete="off">' +
      '<button data-act="comentar" data-id="' + esc(t.id) + '">Enviar</button></div>';
    h += "</div></div>";
    return h;
  }

  function viewFeed() {
    if (state.feed == null) return '<div class="empty">Carregando...</div>';
    if (!state.feed.length) {
      return '<div class="empty">Ninguém treinou ainda.<br>Seja o primeiro: toque no <b>+</b> e registre seu treino. 🏃</div>';
    }
    return state.feed.map(cardTreino).join("");
  }

  function viewRank() {
    var r = state.rank;
    if (!r) return '<div class="empty">Carregando...</div>';
    var t = r.temporada, g = r.regras;
    var modo = state.rankMode;
    var lista = modo === "semana" ? r.semana_ranking : r.temporada_ranking;
    var h = '<div class="card"><div class="row between"><div><b>' + esc(t.nome) + '</b><div class="xs muted">' +
      (t.encerrada ? "Temporada encerrada" : t.iniciada ? "Semana " + t.semana_atual + " de " + t.semanas : "Começa em " + esc(labelData(t.inicio))) +
      "</div></div></div>";
    var pct = t.encerrada ? 100 : t.iniciada ? Math.round((t.semana_atual / t.semanas) * 100) : 0;
    h += '<div class="bar"><i style="width:' + pct + '%"></i></div>';
    h += '<p class="xs muted" style="margin:10px 0 0;line-height:1.5">Treino de pelo menos <b>' + g.minimo_minutos + " min</b> vale 1 ponto (até " + g.max_semana +
      " por semana). Fez " + g.meta_semanal + " ou mais na semana? <b>+1 de bônus</b>. Empate? Quem correu mais minutos fica na frente.</p></div>";
    h += '<div class="seg"><button class="' + (modo === "semana" ? "on" : "") + '" data-act="rankmode" data-v="semana">Esta semana</button>' +
      '<button class="' + (modo === "temporada" ? "on" : "") + '" data-act="rankmode" data-v="temporada">Temporada</button></div>';
    h += '<div class="card" style="padding:4px 14px">';
    var medalhas = ["🥇", "🥈", "🥉"];
    var todosZero = lista.every(function (x) { return x.pontos === 0; });
    lista.forEach(function (x, i) {
      var souEu = state.eu && state.eu.membro.id === x.id;
      h += '<div class="rank linkrow" data-act="verperfil" data-id="' + esc(x.id) + '"><div class="pos">' + (todosZero ? "·" : (medalhas[i] || i + 1)) + "</div>" + avatar(x.nome, x.id) +
        '<div class="grow"><b>' + esc(x.nome) + (souEu ? ' <span class="xs muted">(você)</span>' : "") + (x.sequencia > 0 ? ' <span class="streak" title="Semanas seguidas batendo a meta">' + icon("flame", 12) + " " + x.sequencia + (x.sequencia === 1 ? " semana seguida" : " semanas seguidas") + "</span>" : "") + '</b><div class="xs muted">' + x.treinos + (x.treinos === 1 ? " treino" : " treinos") + " · " + esc(fmtMin(x.minutos)) + "</div></div>" +
        '<div class="pts"><b>' + x.pontos + '</b><div class="xs muted">pts</div></div></div>';
    });
    h += "</div>";
    if (t.encerrada) h += '<p class="small muted center">Quem criou o grupo pode iniciar a próxima temporada na aba Grupo.</p>';
    return h;
  }

  function viewAdd() {
    var f = state.form, eu = state.eu;
    if (!eu) return '<div class="empty">Carregando...</div>';
    var min = eu.grupo.minimo_minutos;
    var opcoes = "";
    [0, 1, 2].forEach(function (n) {
      var iso = addDays(eu.hoje, -n);
      var rot = n === 0 ? "Hoje" : n === 1 ? "Ontem" : "Anteontem";
      opcoes += '<option value="' + n + '"' + (Number(f.dia) === n ? " selected" : "") + ">" + rot + " (" + iso.slice(8) + "/" + iso.slice(5, 7) + ")</option>";
    });
    return '<div class="card"><h3>Registrar treino</h3><p class="small muted" style="margin:6px 0 0">Treino precisa ter pelo menos ' + min + " min pra valer ponto. Um treino por dia.</p>" +
      '<label>Quando?</label><select data-model="form.dia">' + opcoes + "</select>" +
      '<label>Quanto tempo? (minutos)</label><input data-model="form.minutos" value="' + esc(f.minutos) + '" inputmode="numeric" maxlength="3" placeholder="Ex: 35">' +
      '<label>Distância em km (opcional)</label><input data-model="form.km" value="' + esc(f.km) + '" inputmode="decimal" maxlength="6" placeholder="Ex: 5,2">' +
      '<label>Como foi? (opcional)</label><textarea data-model="form.nota" rows="2" maxlength="280" placeholder="Rolou chuva, perna pesada...">' + esc(f.nota) + "</textarea>" +
      '<label>Foto do treino (obrigatória, tirada na hora)</label>' +
      (f.foto ? '<img class="photo" style="max-height:200px" alt="Prévia" src="' + esc(f.foto) + '">' : "") +
      '<button class="btn ghost" style="margin-top:8px" data-act="tirarfototreino">' + (f.foto ? "Tirar outra foto" : "Tirar foto") + "</button>" +
      '<button class="btn" data-act="registrar"' + (state.busy ? " disabled" : "") + ">" + (state.busy ? "Enviando..." : "Registrar treino") + "</button></div>";
  }

  function viewGrupo() {
    var eu = state.eu;
    if (!eu) return '<div class="empty">Carregando...</div>';
    var g = eu.grupo, c = state.cfg, admin = eu.membro.admin;
    if (c.minimo === "") { c.minimo = g.minimo_minutos; c.meta = g.meta_semanal; c.max = g.max_semana; }
    var h = '<div class="card"><b>' + esc(g.nome) + '</b><div class="xs muted" style="margin-top:2px">Toque numa pessoa para ver o perfil</div><div style="margin-top:8px">';
    (eu.membros || []).forEach(function (m) {
      h += '<div class="row between" style="padding:6px 0"><span class="row linkrow" style="gap:8px" data-act="verperfil" data-id="' + esc(m.id) + '">' + avatar(m.nome, m.id) + '<span class="chip">' + esc(m.nome) + (m.id === eu.membro.id ? " (você)" : "") + "</span></span>" +
        (admin ? '<button class="btn small ghost" data-act="resetsenha" data-id="' + esc(m.id) + '" data-nome="' + esc(m.nome) + '">Redefinir senha</button>' : "") + "</div>";
    });
    h += "</div></div>";
    h += viewTemporadas();
    if (admin) {
      h += '<div class="card"><b>Cadastro de novas pessoas</b><p class="xs muted" style="margin:6px 0 0">' +
        (g.cadastro_aberto ? "Aberto: quem tiver o app pode criar conta. Feche quando todo mundo do grupo já tiver entrado." : "Fechado: só você adiciona gente, em Adicionar amigo.") +
        '</p><button class="btn ghost" data-act="cadastro">' + (g.cadastro_aberto ? "Fechar cadastro" : "Abrir cadastro") + "</button></div>";
      h += '<div class="card"><b>Adicionar amigo</b><p class="xs muted" style="margin:6px 0 0">Você define o nome e uma senha inicial, e avisa a pessoa. Ela troca a senha depois, se quiser.</p>' +
        '<label>Nome</label><input data-model="novo.nome" value="' + esc(state.novo.nome) + '" maxlength="24" placeholder="Ex: Ana" autocomplete="off">' +
        '<label>Senha inicial (mínimo 6 caracteres)</label><input data-model="novo.senha" value="' + esc(state.novo.senha) + '" maxlength="64" autocomplete="off">' +
        '<button class="btn ghost" data-act="addmembro">Adicionar</button></div>';
      h += '<div class="card"><b>Regras do grupo</b><p class="xs muted" style="margin:6px 0 0">Mudar no meio da temporada recalcula os pontos de todo mundo.</p>' +
        '<label>Minutos mínimos por treino</label><input data-model="cfg.minimo" value="' + esc(c.minimo) + '" inputmode="numeric" maxlength="3">' +
        '<label>Treinos na semana pra ganhar o bônus</label><input data-model="cfg.meta" value="' + esc(c.meta) + '" inputmode="numeric" maxlength="1">' +
        '<label>Máximo de treinos que contam por semana</label><input data-model="cfg.max" value="' + esc(c.max) + '" inputmode="numeric" maxlength="1">' +
        '<button class="btn ghost" data-act="salvarregras">Salvar regras</button></div>';
      h += '<div class="card"><b>Nova temporada</b><p class="xs muted" style="margin:6px 0 0">Começa quando a atual terminar (ou nesta segunda, se já terminou). O ranking zera.</p>' +
        '<label>Nome</label><input data-model="cfg.tempNome" value="' + esc(c.tempNome) + '" maxlength="40" placeholder="Ex: Temporada 2">' +
        '<label>Semanas (2 a 26)</label><input data-model="cfg.tempSemanas" value="' + esc(c.tempSemanas) + '" inputmode="numeric" maxlength="2">' +
        '<button class="btn ghost" data-act="novatemp">Criar temporada</button></div>';
    }
    return h;
  }

  function viewTemporadas() {
    var T = state.temps;
    if (!T) return "";
    var h = '<div class="card"><b>Temporadas</b>';
    T.forEach(function (t) {
      var top = (t.ranking || []).filter(function (x) { return x.pontos > 0; }).slice(0, 3);
      h += '<div class="temp"><div class="row between"><b>' + esc(t.nome) + '</b><span class="xs muted">' + (t.encerrada ? "encerrada" : "em andamento") + "</span></div>" +
        '<div class="xs muted">' + esc(labelData(t.inicio)) + " a " + esc(labelData(t.fim)) + " · " + t.semanas + " semanas</div>";
      if (!top.length) h += '<div class="xs muted" style="margin-top:4px">Ninguém pontuou ainda.</div>';
      else {
        var med = ["🥇", "🥈", "🥉"];
        h += '<div style="margin-top:6px">' + top.map(function (x, i) { return med[i] + " " + esc(x.nome) + " <span class='xs muted'>" + x.pontos + " pts</span>"; }).join("<br>") + "</div>";
      }
      h += "</div>";
    });
    return h + "</div>";
  }

  function viewPerfil() {
    var eu = state.eu;
    if (!eu) return '<div class="empty">Carregando...</div>';
    var p = state.perfil, d = p && p.dados;
    var meu = !p || !p.id || p.id === eu.membro.id;
    var h = "";
    if (!meu) h += '<button class="btn small ghost" style="margin-bottom:10px" data-act="voltarperfil">Voltar</button>';
    if (!d) return h + '<div class="empty">Carregando...</div>';
    if (d.erro) return h + '<div class="empty">' + esc(d.erro) + "</div>";
    var t = d.totais, admin = eu.membro.admin;
    var avHtml = meu ? '<button class="avedit" data-act="editarfoto" aria-label="Editar foto de perfil">' + avatar(d.membro.nome, d.membro.id) + '<span class="avbadge">' + icon("camera", 14) + "</span></button>" : avatar(d.membro.nome, d.membro.id);
    h += '<div class="card perfilhead big">' + avHtml + '<div class="grow"><b style="font-size:18px">' + esc(d.membro.nome) + "</b>" +
      '<div class="xs muted" style="margin-top:2px">' + (t.sequencia > 0 ? icon("flame", 14) + " " + t.sequencia + (t.sequencia === 1 ? " semana seguida" : " semanas seguidas") : "Sem sequência ativa") + "</div></div></div>";
    h += '<div class="card"><div class="stat"><div><b>' + t.treinos + "</b><span>treinos</span></div><div><b>" + esc(fmtMin(t.minutos)) + "</b><span>tempo</span></div>" +
      "<div><b>" + esc(fmtKm(t.km)) + "</b><span>km</span></div><div><b>" + t.melhor_sequencia + "</b><span>melhor seq.</span></div></div></div>";
    // calendário das últimas 16 semanas
    var mapa = {};
    (d.dias || []).forEach(function (x) { mapa[x.data] = x; });
    var parts = eu.hoje.split("-"), dow = (new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2])).getDay() + 6) % 7;
    var ini = addDays(eu.hoje, -dow - 15 * 7), cel = "";
    for (var i = 0; i < 16 * 7; i++) {
      var dt = addDays(ini, i);
      if (dt > eu.hoje) { cel += '<i class="hz"></i>'; continue; }
      var x = mapa[dt], cls = "";
      if (x) cls = x.contestado ? " cx" : x.minutos >= 60 ? " l3" : x.minutos >= 30 ? " l2" : " l1";
      cel += '<i class="hc' + cls + '"' + (x ? ' title="' + esc(labelData(dt)) + ": " + esc(fmtMin(x.minutos)) + '"' : "") + "></i>";
    }
    h += '<div class="card"><b>Últimas 16 semanas</b><div class="heat">' + cel + '</div><div class="xs muted" style="margin-top:6px">Cada quadrado é um dia. Quanto mais forte a cor, mais minutos.</div></div>';
    h += '<div class="card"><b>Medalhas</b><span class="xs muted" style="margin-left:8px">' + (d.conquistas || []).filter(function (q) { return q.ok; }).length + "/" + (d.conquistas || []).length + '</span><div class="conq">' + (d.conquistas || []).map(function (q) {
      return '<div class="cq' + (q.ok ? " on" : "") + '">' + medalha(q.id, q.ok) + '<b>' + esc(q.titulo) + '</b><span>' + esc(q.desc) + "</span></div>";
    }).join("") + "</div></div>";
    if (!meu) return h;
    var nt = eu.membro.notif || { treino: true, comentario: true, contestado: true, reacao: true, resumo: true };
    var lc = lembCfg();
    function sw(act, k, titulo, desc, on) {
      return '<label class="srow"><span class="stxt"><b>' + titulo + "</b><span>" + desc + '</span></span><span class="switch"><input type="checkbox" data-act-change="' + act + '"' +
        (k ? ' data-k="' + k + '"' : "") + (on ? " checked" : "") + "><i></i></span></label>";
    }
    h += '<h2 class="sec">Avisos</h2><div class="card list">' +
      (state.pushPerm === "denied" ? '<div class="alerta">' + icon("bell", 18) + '<span>Os avisos estão bloqueados no Android. Libere em Configurações, Apps, Corre Lento, Notificações.</span></div>' : "") +
      sw("notif", "treino", "Treinos dos amigos", "Quando alguém registrar um treino", nt.treino) +
      sw("notif", "comentario", "Comentários", "Quando comentarem no seu treino", nt.comentario) +
      sw("notif", "reacao", "Reações", "Quando reagirem ao seu treino", nt.reacao !== false) +
      sw("notif", "contestado", "Treino contestado", "Quando o grupo duvidar de um treino seu", nt.contestado) +
      sw("notif", "resumo", "Resumo da semana", "Domingo às 21h, com o ranking", nt.resumo !== false) + "</div>";
    h += '<h2 class="sec">Lembrete</h2><div class="card list">' +
      sw("lembrete", "", "Lembrete diário", "Só avisa se você ainda não registrou treino no dia", lc.on) +
      (lc.on ? '<div class="srow"><span class="stxt"><b>Horário</b></span><input type="time" class="timechip" value="' + esc(lc.hora) + '" data-act-change="lembhora"></div>' : "") + "</div>";
    h += '<h2 class="sec">Conta</h2><div class="card list">' +
      '<button class="lrow" data-act="abrirsenha"><span class="lico">' + icon("lock", 20) + '</span><span class="stxt"><b>Trocar senha</b></span>' + icon("chevron", 18) + "</button>" +
      '<button class="lrow danger" data-act="sair"><span class="lico">' + icon("logout", 20) + '</span><span class="stxt"><b>Sair deste aparelho</b></span></button></div>';
    h += '<p class="xs muted center" style="margin:6px 0 18px">Corre Lento' + (state.appInfo ? " v" + esc(state.appInfo.version) : "") + " · pacote " + esc(C.WEB_VERSION) + "</p>";
    return h;
  }

  function viewMain() {
    var eu = state.eu, titulo = eu ? eu.grupo.nome : "Corre Lento";
    var sub = "";
    if (state.rank) sub = state.rank.temporada.nome + (state.rank.temporada.iniciada && !state.rank.temporada.encerrada ? " · semana " + state.rank.temporada.semana_atual + "/" + state.rank.temporada.semanas : "");
    var corpo = state.tab === "feed" ? viewFeed() : state.tab === "rank" ? viewRank() : state.tab === "add" ? viewAdd() : state.tab === "perfil" ? viewPerfil() : viewGrupo();
    function tab(id, ic, rot, extra) {
      return '<button class="tab' + (state.tab === id ? " active" : "") + (extra || "") + '" data-act="tab" data-v="' + id + '"><span class="ic">' + ic + "</span>" + rot + "</button>";
    }
    return viewUpdate() + '<div class="topbar"><div><h1>' + esc(titulo) + '</h1><div class="sub">' + esc(sub) + "</div></div>" +
      '<button class="iconbtn" data-act="atualizar" aria-label="Atualizar">' + icon("refresh", 20) + '</button></div>' +
      '<div class="content" id="content">' + corpo + "</div>" +
      '<nav class="tabbar">' + tab("feed", icon("home"), "Feed") + tab("rank", icon("trophy"), "Ranking") + tab("add", icon("plus", 26), "Treinei", " plus") + tab("grupo", icon("users"), "Grupo") + tab("perfil", icon("user"), "Perfil") + "</nav>";
  }

  function render() {
    var app = document.getElementById("app");
    var old = document.getElementById("content");
    var scroll = old ? old.scrollTop : 0;
    app.innerHTML = state.token ? viewMain() : viewAuth();
    var nw = document.getElementById("content");
    if (nw) nw.scrollTop = scroll;
  }

  // ---------- ações ----------
  function guard(fn) {
    return function (el) {
      if (state.busy) return;
      return fn(el);
    };
  }
  function withBusy(promise, okMsg) {
    state.busy = true; render();
    return promise.then(function (r) { state.busy = false; if (okMsg) toast(okMsg); return r; },
      function (e) { state.busy = false; render(); toast(e.message, true); throw e; });
  }

  function resizeImage(file) {
    return new Promise(function (resolve, reject) {
      var img = new Image();
      var url = typeof file === "string" ? file : URL.createObjectURL(file);
      img.onload = function () {
        function gerar(max, q) {
          var s = Math.min(1, max / Math.max(img.width, img.height));
          var c = document.createElement("canvas");
          c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
          c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
          return c.toDataURL("image/jpeg", q);
        }
        var out = gerar(900, 0.65);
        if (out.length > 380000) out = gerar(700, 0.5);
        if (out.length > 380000) out = gerar(520, 0.45);
        URL.revokeObjectURL(url);
        resolve(out);
      };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error("Não consegui ler essa foto")); };
      img.src = url;
    });
  }

  function cropSquare(file, size) {
    return new Promise(function (resolve, reject) {
      var img = new Image(), url = URL.createObjectURL(file);
      img.onload = function () {
        var lado = Math.min(img.width, img.height);
        var c = document.createElement("canvas");
        c.width = size; c.height = size;
        c.getContext("2d").drawImage(img, (img.width - lado) / 2, (img.height - lado) / 2, lado, lado, 0, 0, size, size);
        URL.revokeObjectURL(url);
        resolve(c.toDataURL("image/jpeg", 0.75));
      };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error("Não consegui ler essa foto")); };
      img.src = url;
    });
  }

  // recorte da foto de perfil: arrastar para posicionar, barra/pinça para aproximar
  function abrirRecorte(file, aoSalvar) {
    var url = typeof file === "string" ? file : URL.createObjectURL(file), img = new Image();
    img.onerror = function () { URL.revokeObjectURL(url); toast("Não consegui ler essa foto", true); };
    img.onload = function () {
      var S = 280, base = S / Math.min(img.width, img.height), zoom = 1, ox = 0, oy = 0;
      var ov = document.createElement("div");
      ov.className = "cropper";
      ov.innerHTML = '<div class="cropbox"><b>Ajuste sua foto</b>' +
        '<p class="xs muted" style="margin:4px 0 12px">Arraste para posicionar e use a barra para aproximar.</p>' +
        '<div class="cropwrap"><canvas width="' + S + '" height="' + S + '"></canvas></div>' +
        '<input type="range" min="1" max="4" step="0.01" value="1" class="croprange">' +
        '<div class="row" style="gap:8px;margin-top:14px"><button class="btn ghost grow" data-c="x">Cancelar</button>' +
        '<button class="btn grow" data-c="ok">Salvar foto</button></div></div>';
      document.body.appendChild(ov);
      var cv = ov.querySelector("canvas"), ctx = cv.getContext("2d"), rg = ov.querySelector("input");
      function limitar() {
        var mx = (img.width * base * zoom - S) / 2, my = (img.height * base * zoom - S) / 2;
        ox = Math.max(-mx, Math.min(mx, ox)); oy = Math.max(-my, Math.min(my, oy));
      }
      function desenhar(c, size) {
        var k = size / S, w = img.width * base * zoom * k, h = img.height * base * zoom * k;
        c.fillStyle = "#000"; c.fillRect(0, 0, size, size);
        c.drawImage(img, size / 2 - w / 2 + ox * k, size / 2 - h / 2 + oy * k, w, h);
      }
      function pintar() { limitar(); desenhar(ctx, S); }
      pintar();
      var pts = {}, ultDist = 0;
      function dist() { var k = Object.keys(pts); return k.length < 2 ? 0 : Math.hypot(pts[k[0]].x - pts[k[1]].x, pts[k[0]].y - pts[k[1]].y); }
      cv.addEventListener("pointerdown", function (e) { cv.setPointerCapture(e.pointerId); pts[e.pointerId] = { x: e.clientX, y: e.clientY }; ultDist = dist(); });
      cv.addEventListener("pointermove", function (e) {
        var a = pts[e.pointerId]; if (!a) return;
        var n = Object.keys(pts).length;
        if (n === 1) { ox += e.clientX - a.x; oy += e.clientY - a.y; }
        a.x = e.clientX; a.y = e.clientY;
        if (n >= 2) {
          var d = dist();
          if (ultDist) { zoom = Math.max(1, Math.min(4, zoom * d / ultDist)); rg.value = zoom; }
          ultDist = d;
        }
        pintar();
      });
      function soltar(e) { delete pts[e.pointerId]; ultDist = dist(); }
      cv.addEventListener("pointerup", soltar); cv.addEventListener("pointercancel", soltar);
      rg.addEventListener("input", function () { zoom = Number(rg.value); pintar(); });
      function fechar() { URL.revokeObjectURL(url); ov.remove(); }
      ov.addEventListener("click", function (e) {
        var c = e.target && e.target.dataset && e.target.dataset.c;
        if (c === "x") fechar();
        if (c === "ok") {
          var oc = document.createElement("canvas"); oc.width = 192; oc.height = 192;
          desenhar(oc.getContext("2d"), 192);
          var d = oc.toDataURL("image/jpeg", 0.8);
          fechar(); aoSalvar(d);
        }
      });
    };
    img.src = url;
  }

  function salvarAvatar(d) {
    rpc("corrida_avatar_definir", tk({ p_imagem: d })).then(function (r) {
      if (r && r.erro) { toast(r.erro, true); return; }
      toast("Foto atualizada");
      return loadMe().then(function () { loadAvatars(); render(); });
    }, function (err) { toast(err.message, true); });
  }
  function pegarFotoPerfil(fonte) {
    var Cm = plug("Camera");
    if (Cm) {
      Cm.getPhoto({ quality: 85, allowEditing: false, resultType: "dataUrl", source: fonte, correctOrientation: true, saveToGallery: false, width: 1280 })
        .then(function (r) { abrirRecorte(r.dataUrl, salvarAvatar); }, function (e) {
          if (!/cancel/i.test(String(e && (e.message || e)))) toast("Não consegui abrir a " + (fonte === "CAMERA" ? "câmera" : "galeria"), true);
        });
      return;
    }
    var inp = document.createElement("input");
    inp.type = "file"; inp.accept = "image/*";
    inp.onchange = function () { if (inp.files && inp.files[0]) abrirRecorte(inp.files[0], salvarAvatar); };
    inp.click();
  }

  function nint(v) { var n = parseInt(String(v).trim(), 10); return isNaN(n) ? null : n; }

  var acts = {
    tab: function (el) {
      state.tab = el.dataset.v; render();
      if (state.tab === "perfil") carregarPerfil(null);
      if (state.tab === "grupo") carregarTemporadas();
      if (state.tab === "feed" || state.tab === "rank" || state.tab === "grupo" || state.tab === "perfil") refreshAll(true);
    },
    verperfil: function (el) { state.perfilOrigem = state.tab; state.tab = "perfil"; carregarPerfil(el.dataset.id); },
    voltarperfil: function () { state.tab = state.perfilOrigem || "grupo"; state.perfil = null; render(); },
    atualizar: function () { toast("Atualizando..."); refreshAll(false); checkUpdate(); },
    atualizarapp: function () {
      var u = state.update;
      if (!u || !/^https:\/\//.test(u.apk_url)) return;
      var B = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Browser;
      if (B && B.open) B.open({ url: u.apk_url }).catch(function () { window.open(u.apk_url, "_blank"); });
      else window.open(u.apk_url, "_blank");
      toast("Baixe o arquivo e toque nele pra instalar");
    },
    aplicarota: function () {
      var o = state.ota, U = updater();
      if (!o || !U) return;
      if (o.status !== "pronta") { toast("Baixando, só um instante..."); return; }
      toast("Atualizando...");
      U.set({ id: o.id }).catch(function () { toast("Não consegui aplicar. Tente de novo.", true); });
    },
    depoisota: function () { if (state.ota) { state.otaDismissed = state.ota.version; render(); } },
    depois: function () { if (state.update) { state.updateDismissed = state.update.version_code; render(); } },
    rankmode: function (el) { state.rankMode = el.dataset.v; render(); },
    authmode: function (el) { state.authMode = el.dataset.v; render(); },
    auth: guard(function () {
      var a = state.auth, criar = state.authMode === "criar", p;
      if (criar) {
        if (a.senha !== a.senha2) { toast("As senhas não são iguais", true); return; }
        p = rpc("corrida_cadastrar", { p_nome: a.nome, p_senha: a.senha });
      } else {
        p = rpc("corrida_login", { p_nome: a.nome, p_senha: a.senha }).then(function (d) {
          if (d && d.erro) throw new Error(d.erro);
          return d;
        });
      }
      withBusy(p).then(function (d) {
        return entrou(d.token).then(function () {
          if (criar) toast(d.admin ? "Conta criada! Você organiza o grupo." : "Conta criada! Bora correr.");
        });
      }, function () {});
    }),
    cadastro: function () {
      var abrir = !state.eu.grupo.cadastro_aberto;
      rpc("corrida_config_cadastro", tk({ p_aberto: abrir })).then(function () {
        toast(abrir ? "Cadastro aberto" : "Cadastro fechado");
        return loadMe();
      }).then(render, function (e) { toast(e.message, true); });
    },
    registrar: guard(function () {
      var f = state.form, eu = state.eu;
      var min = nint(f.minutos);
      if (min == null || min < 1) { toast("Informe quantos minutos você treinou", true); return; }
      if (min < eu.grupo.minimo_minutos) { toast("O treino precisa ter pelo menos " + eu.grupo.minimo_minutos + " min pra valer ponto", true); return; }
      var km = null;
      if (String(f.km).trim() !== "") {
        km = parseFloat(String(f.km).replace(",", "."));
        if (isNaN(km) || km < 0 || km > 250) { toast("Distância inválida", true); return; }
      }
      if (!f.foto) { toast("Tire uma foto do treino para registrar", true); return; }
      var data = addDays(eu.hoje, -Number(f.dia));
      withBusy(rpc("corrida_registrar_treino", tk({ p_data: data, p_minutos: min, p_km: km, p_nota: f.nota || null, p_foto: f.foto, p_camera: true })), "Treino registrado! 🔥")
        .then(function () {
          state.form = { dia: 0, minutos: "", km: "", nota: "", foto: null };
          state.tab = "feed";
          return refreshAll(false);
        }, function () {});
    }),
    reagir: function (el) {
      rpc("corrida_reagir", tk({ p_id: el.dataset.id, p_emoji: el.dataset.e })).then(loadFeed).then(render, function (e) { toast(e.message, true); });
    },
    duvidar: function (el) {
      rpc("corrida_contestar", tk({ p_id: el.dataset.id })).then(function (r) {
        toast(r.contestado ? "Treino contestado pelo grupo" : "Dúvida registrada");
        return Promise.all([loadFeed(), loadRank()]);
      }).then(render, function (e) { toast(e.message, true); });
    },
    comentar: function (el) {
      var id = el.dataset.id, txt = (state.drafts[id] || "").trim();
      if (!txt) return;
      rpc("corrida_comentar", tk({ p_id: id, p_texto: txt })).then(function () {
        state.drafts[id] = "";
        return loadFeed();
      }).then(render, function (e) { toast(e.message, true); });
    },
    foto: function (el) {
      var id = el.dataset.id;
      el.textContent = "Carregando...";
      rpc("corrida_foto", tk({ p_id: id })).then(function (d) { state.photos[id] = d; render(); }, function (e) { toast(e.message, true); render(); });
    },
    menutreino: function (el) {
      var id = el.dataset.id;
      sheet({ titulo: "Treino", acoes: [
        { rotulo: "Excluir treino", tipo: "danger", icone: "trash", fn: function () {
          setTimeout(function () {
            confirmar("Excluir este treino?", "Os pontos e a foto deste treino serão removidos. Isso não pode ser desfeito.", "Excluir", function () {
              rpc("corrida_apagar_treino", tk({ p_id: id })).then(function () { toast("Treino excluído"); return refreshAll(true); }, function (e) { toast(e.message, true); });
            });
          }, 240);
        } },
        { rotulo: "Cancelar" }
      ] });
    },
    addmembro: function () {
      var n = state.novo;
      rpc("corrida_admin_add_membro", tk({ p_nome: n.nome, p_senha: n.senha })).then(function () {
        toast("Adicionado! Passe o nome e a senha inicial pra " + n.nome.trim());
        state.novo = { nome: "", senha: "" };
        return loadMe();
      }).then(render, function (e) { toast(e.message, true); });
    },
    resetsenha: function (el) {
      var id = el.dataset.id, nome = el.dataset.nome;
      sheet({ titulo: "Redefinir senha de " + nome, texto: "Defina uma senha provisória e avise a pessoa. Ela pode trocar depois, na aba Perfil.",
        campos: [{ id: "nova", rotulo: "Nova senha (mínimo 6 caracteres)", tipo: "text", ph: "Ex: corre123" }],
        acoes: [{ rotulo: "Redefinir senha", tipo: "primary", fn: function (v) {
          if (!v.nova || v.nova.length < 6) { toast("A senha precisa ter pelo menos 6 caracteres", true); return false; }
          rpc("corrida_admin_redefinir_senha", tk({ p_membro: id, p_senha: v.nova })).then(function () {
            toast("Senha de " + nome + " redefinida. Avise a pessoa.");
          }, function (e) { toast(e.message, true); });
        } }, { rotulo: "Cancelar" }] });
    },
    abrirsenha: function () {
      sheet({ titulo: "Trocar senha",
        campos: [{ id: "atual", rotulo: "Senha atual", tipo: "password" }, { id: "nova", rotulo: "Nova senha (mínimo 6 caracteres)", tipo: "password" }],
        acoes: [{ rotulo: "Trocar senha", tipo: "primary", fn: function (v) {
          if (!v.atual || !v.nova) { toast("Preencha as duas senhas", true); return false; }
          rpc("corrida_trocar_senha", tk({ p_atual: v.atual, p_nova: v.nova })).then(function () { toast("Senha trocada"); }, function (e) { toast(e.message, true); });
        } }, { rotulo: "Cancelar" }] });
    },
    editarfoto: function () {
      var tenho = !!(state.eu && state.avatares[state.eu.membro.id] && state.avatares[state.eu.membro.id].img);
      var acoes = [
        { rotulo: "Tirar foto", tipo: "ghost", icone: "camera", fn: function () { pegarFotoPerfil("CAMERA"); } },
        { rotulo: "Escolher da galeria", tipo: "ghost", icone: "image", fn: function () { pegarFotoPerfil("PHOTOS"); } }
      ];
      if (tenho) acoes.push({ rotulo: "Remover foto", tipo: "danger", icone: "trash", fn: function () {
        rpc("corrida_avatar_definir", tk({ p_imagem: null })).then(function () { toast("Foto removida"); return loadMe(); }).then(function () { loadAvatars(); render(); }, function (e) { toast(e.message, true); });
      } });
      acoes.push({ rotulo: "Cancelar" });
      sheet({ titulo: "Foto de perfil", acoes: acoes });
    },
    tirarfototreino: function () {
      var Cm = plug("Camera");
      if (!Cm) { toast("A câmera só funciona no app instalado", true); return; }
      Cm.getPhoto({ quality: 75, allowEditing: false, resultType: "dataUrl", source: "CAMERA", correctOrientation: true, saveToGallery: false, width: 1280 })
        .then(function (r) { return resizeImage(r.dataUrl); })
        .then(function (d) { state.form.foto = d; render(); }, function (e) {
          if (!/cancel/i.test(String(e && (e.message || e)))) toast("Não consegui abrir a câmera", true);
        });
    },
    tirarfoto: function () {
      rpc("corrida_avatar_definir", tk({ p_imagem: null })).then(function () { toast("Foto removida"); return loadMe(); }).then(function () { loadAvatars(); render(); }, function (e) { toast(e.message, true); });
    },
    trocarsenha: function () {
      var p = state.pw;
      rpc("corrida_trocar_senha", tk({ p_atual: p.atual, p_nova: p.nova })).then(function () {
        state.pw = { atual: "", nova: "" };
        toast("Senha trocada");
        render();
      }, function (e) { toast(e.message, true); });
    },
    salvarregras: function () {
      var c = state.cfg;
      rpc("corrida_config", tk({ p_minimo: nint(c.minimo), p_meta: nint(c.meta), p_max: nint(c.max) })).then(function () {
        toast("Regras salvas"); return refreshAll(true);
      }, function (e) { toast(e.message, true); });
    },
    novatemp: function () {
      var c = state.cfg;
      rpc("corrida_nova_temporada", tk({ p_nome: c.tempNome, p_semanas: nint(c.tempSemanas) })).then(function () {
        toast("Temporada criada"); c.tempNome = ""; return refreshAll(true);
      }, function (e) { toast(e.message, true); });
    },
    sair: function () {
      confirmar("Sair deste aparelho?", "Você volta a entrar com seu nome e senha. Seus treinos continuam salvos.", "Sair", function () { sair(false); });
    }
  };

  document.addEventListener("click", function (e) {
    var el = e.target.closest("[data-act]");
    if (!el) return;
    var fn = acts[el.dataset.act];
    if (fn) fn(el);
  });

  document.addEventListener("input", function (e) {
    var t = e.target;
    if (t.dataset && t.dataset.model) {
      var parts = t.dataset.model.split(".");
      state[parts[0]][parts[1]] = t.value;
    } else if (t.dataset && t.dataset.draft) {
      state.drafts[t.dataset.draft] = t.value;
    }
  });

  document.addEventListener("change", function (e) {
    var t = e.target;
    if (t.dataset && t.dataset.model && t.tagName === "SELECT") {
      var parts = t.dataset.model.split(".");
      state[parts[0]][parts[1]] = t.value;
    }
    if (t.dataset && t.dataset.actChange === "notif") {
      var args = {}; args["p_" + t.dataset.k] = !!t.checked;
      rpc("corrida_notif_prefs", tk(args)).then(function () { return loadMe(); }).then(render, function (e) { toast(e.message, true); });
    }
    if (t.dataset && t.dataset.actChange === "lembrete") {
      var cfg = lembCfg(); cfg.on = !!t.checked; LS.set("cc_lembrete", JSON.stringify(cfg));
      var L = plug("LocalNotifications");
      var go = L && cfg.on ? L.requestPermissions().then(function (r) { if (r.display !== "granted") { cfg.on = false; LS.set("cc_lembrete", JSON.stringify(cfg)); toast("Libere as notificações do app no Android", true); } }) : Promise.resolve();
      go.catch(noop).then(function () { agendarLembrete(true); render(); });
    }
    if (t.dataset && t.dataset.actChange === "lembhora" && t.value) {
      var c2 = lembCfg(); c2.hora = t.value; LS.set("cc_lembrete", JSON.stringify(c2)); agendarLembrete(true); render();
    }
    if (t.dataset && t.dataset.actChange === "foto" && t.files && t.files[0]) {
      resizeImage(t.files[0]).then(function (d) { state.form.foto = d; render(); }, function (err) { toast(err.message, true); });
    }
  });

  // enter nos campos de comentário
  document.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && e.target.dataset && e.target.dataset.draft) {
      var btn = e.target.parentNode.querySelector('[data-act="comentar"]');
      if (btn) btn.click();
    }
  });

  // atualização periódica (só se o usuário não estiver digitando)
  setInterval(function () {
    if (!state.token || document.hidden || state.busy) return;
    var ae = document.activeElement;
    if (ae && (ae.tagName === "INPUT" || ae.tagName === "TEXTAREA" || ae.tagName === "SELECT")) return;
    if (state.tab === "feed" || state.tab === "rank") refreshAll(true);
  }, 60000);
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) return;
    checkUpdate();
    if (state.token) refreshAll(true);
  });

  // ---------- início ----------
  render();
  notifyReady();
  if (state.token) registrarPush();
  loadAppInfo().then(render);
  checkUpdate();
  if (state.token) refreshAll(true);
})();
