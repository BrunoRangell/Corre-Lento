// Chave publicável do Supabase (pode ficar no app, só chama funções RPC com token de sessão do grupo)
window.CONFIG = {
  SUPABASE_URL: "https://igxyvnwrubygkbgxcvbd.supabase.co",
  SUPABASE_KEY: "sb_publishable_VXtY5817TA33DOjJt8iaQA_n014SOp0",
  // usado só como reserva fora do Android; no app o número real vem do versionCode do APK
  APP_VERSION_CODE: 8,
  // versão dos arquivos do app (sobe a cada atualização instantânea)
  WEB_VERSION: 21
};
